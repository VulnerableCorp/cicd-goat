/// <reference types="react-scripts" />

interface Window {
  eel: any;
}

declare var window: Window;
